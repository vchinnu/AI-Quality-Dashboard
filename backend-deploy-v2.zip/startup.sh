#!/bin/bash
echo "Starting AI Quality Dashboard Backend"
cd /home/site/wwwroot
python server_azure.py